package com.rse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiskScoringEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiskScoringEngineApplication.class, args);
	}

}
