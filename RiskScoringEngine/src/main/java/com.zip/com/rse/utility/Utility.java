package com.rse.utility;

import org.springframework.stereotype.Component;

import com.rse.model.RseTransactionDetails;
import com.rse.model.RseTxnParameterCount;
import com.rse.model.RseTxnPercentage;
import com.rse.model.RseWeightageMaster;

@Component
public class Utility {

	public RseTxnParameterCount getMachedCount(RseTransactionDetails txnDetails, RseTxnParameterCount parameterCount, RseTransactionDetails recTxnDetails){
		
		parameterCount.setTotalRecordCount(parameterCount.getTotalRecordCount()+1);
		
		if(txnDetails.getAcctNumber() != null  && recTxnDetails.getAcctNumber() != null  
				&& txnDetails.getAcctNumber().equals(recTxnDetails.getAcctNumber()))
			parameterCount.setAcctNumber(parameterCount.getAcctNumber()+1);
		
		if(txnDetails.getAcctType() != null  && recTxnDetails.getAcctType() != null  
				&& txnDetails.getAcctType().equals(recTxnDetails.getAcctType())) 
			parameterCount.setAcctType(parameterCount.getAcctType()+1);
		
		if(txnDetails.getBrand() != null  && recTxnDetails.getBrand() != null  
				&& txnDetails.getBrand().equals(recTxnDetails.getBrand())) 
			parameterCount.setBrand(parameterCount.getBrand()+1);
		
		if(txnDetails.getBrowserAcceptHeader() != null  && recTxnDetails.getBrowserAcceptHeader() != null  
				&& txnDetails.getBrowserAcceptHeader().equals(recTxnDetails.getBrowserAcceptHeader()))
			parameterCount.setBrowserAcceptHeader(parameterCount.getBrowserAcceptHeader()+1);
		
		if(txnDetails.getBrowserIP() != null  && recTxnDetails.getBrowserIP() != null  
				&& txnDetails.getBrowserIP().equals(recTxnDetails.getBrowserIP())) 
			parameterCount.setBrowserIP(parameterCount.getBrowserIP()+1);
		
		if(txnDetails.getBrowserLanguage() != null  && recTxnDetails.getBrowserLanguage() != null  
				&& txnDetails.getBrowserLanguage().equals(recTxnDetails.getBrowserLanguage())) 
			parameterCount.setBrowserLanguage(parameterCount.getBrowserLanguage()+1);
		
		if(txnDetails.getCardExpiryDate() != null  && recTxnDetails.getCardExpiryDate() != null 
				&& txnDetails.getCardExpiryDate().equals(recTxnDetails.getCardExpiryDate()))
			parameterCount.setCardExpiryDate(parameterCount.getCardExpiryDate()+1);
		
		if(txnDetails.getCardExpiryDate() != null  && recTxnDetails.getCardExpiryDate() != null  
				&& txnDetails.getCardExpiryDate().equals(recTxnDetails.getCardExpiryDate()))
			parameterCount.setCardExpiryDate(parameterCount.getCardExpiryDate()+1);
		
		if(txnDetails.getCardholderName() != null  && recTxnDetails.getCardholderName() != null  
				&& txnDetails.getCardholderName().equals(recTxnDetails.getCardholderName()))
			parameterCount.setCardHolderName(parameterCount.getCardHolderName()+1);
		
		if(txnDetails.getDeviceModel() != null  && recTxnDetails.getDeviceModel() != null  
				&& txnDetails.getDeviceModel().equals(recTxnDetails.getDeviceModel()))
			parameterCount.setDeviceModel(parameterCount.getDeviceModel()+1);
		
		if(txnDetails.getDeviceName() != null  && recTxnDetails.getDeviceName() != null  
				&& txnDetails.getDeviceName().equals(recTxnDetails.getDeviceName()))
			parameterCount.setDeviceName(parameterCount.getDeviceName()+1);
		
		if(txnDetails.getEmail() != null  && recTxnDetails.getEmail() != null  
				&& txnDetails.getEmail().equals(recTxnDetails.getEmail()))
			parameterCount.setEmail(parameterCount.getEmail()+1);
		
		if(txnDetails.getIpAddress() != null && recTxnDetails.getIpAddress() != null 
				&& txnDetails.getIpAddress() .equals(recTxnDetails.getIpAddress()))
			parameterCount.setIpAddress(parameterCount.getIpAddress()+1);
		
		if(txnDetails.getMerchantCntryCode() != null  && recTxnDetails.getMerchantCntryCode() != null  
				&& txnDetails.getMerchantCntryCode() .equals(recTxnDetails.getMerchantCntryCode()))
			parameterCount.setMerchantCntryCode(parameterCount.getMerchantCntryCode()+1);
		
		if(txnDetails.getIpAddress() != null  && recTxnDetails.getIpAddress() != null 
				&& txnDetails.getIpAddress() .equals(recTxnDetails.getIpAddress()))
			parameterCount.setIpAddress(parameterCount.getIpAddress()+1);
		
		if(txnDetails.getMerchantMCC() != null  && recTxnDetails.getMerchantMCC() != null 
				&& txnDetails.getMerchantMCC() .equals(recTxnDetails.getMerchantMCC()))
			parameterCount.setMerchantMCC(parameterCount.getMerchantMCC()+1);
		
		if(txnDetails.getMerchantName() != null  && recTxnDetails.getMerchantName() != null  
				&& txnDetails.getMerchantName() .equals(recTxnDetails.getMerchantName()))
			parameterCount.setMerchantName(parameterCount.getMerchantName()+1);
		
		if(txnDetails.getOsName() != null  && recTxnDetails.getOsName() != null  
				&& txnDetails.getOsName() .equals(recTxnDetails.getOsName()))
			parameterCount.setOsName(parameterCount.getOsName()+1);
		
		if(txnDetails.getOsVersion() != null  && recTxnDetails.getOsVersion() != null 
				&& txnDetails.getOsVersion() .equals(recTxnDetails.getOsVersion()))
			parameterCount.setOsVersion(parameterCount.getOsVersion()+1);
		
		if(txnDetails.getPlatform() != null && recTxnDetails.getPlatform() != null 
				&& txnDetails.getPlatform() .equals(recTxnDetails.getPlatform()))
			parameterCount.setPlatform(parameterCount.getPlatform()+1);
		
		if(txnDetails.getPurchaseAmount() != null  && recTxnDetails.getPurchaseAmount() != null  
				&& txnDetails.getPurchaseAmount() .equals(recTxnDetails.getPurchaseAmount()))
			parameterCount.setPurchaseAmount(parameterCount.getPurchaseAmount()+1);
		
		if(txnDetails.getPurchaseCurrency() != null  && recTxnDetails.getPurchaseCurrency() != null 
				&& txnDetails.getPurchaseCurrency() .equals(recTxnDetails.getPurchaseCurrency()))
			parameterCount.setPurchaseCurrency(parameterCount.getPurchaseCurrency()+1);
		
		if(txnDetails.getShippingAddress() != null  && recTxnDetails.getShippingAddress() != null  
				&& txnDetails.getShippingAddress() .equals(recTxnDetails.getShippingAddress()))
			parameterCount.setShippingAddress(parameterCount.getShippingAddress()+1);
		
		if(txnDetails.getTimeZone() != null && recTxnDetails.getTimeZone() != null  
				&& txnDetails.getTimeZone() .equals(recTxnDetails.getTimeZone()))
			parameterCount.setTimeZone(parameterCount.getTimeZone()+1);
		
		if(txnDetails.getTxndateTime() != null  && recTxnDetails.getTxndateTime() != null 
				&& txnDetails.getTxndateTime().equals(recTxnDetails.getTxndateTime()))
			parameterCount.setTxnDateTime(parameterCount.getTxnDateTime()+1);
		
		return parameterCount ;
	}
	
	/*public calculateRiskScore(RseWeightageMaster master, RseTxnParameterCount parameterCount,int totalTxnCount,int grandScore,int grandTotal, RseTxnPercentage parameterPercentage) {
		//weights.forEach(master -> utility.calculateRiskScore(master,parameterCount,totalTxnCount,grandScore,grandTotal,parameterPercentage));
		
		
			int weight,fieldCount = 0;
			String parameterPercent;
			
			switch(master.getFieldName()) {
			case "acctNumber":
				weight=master.getWeight();
				fieldCount=parameterCount.getAcctNumber(); 
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setAcctNumber(parameterPercent);
				break;	
			case "txnId":
				weight=master.getWeight();
				fieldCount=parameterCount.getTxnId();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setTxnId(parameterPercent);
				break;	
			case "cardExpiryDate":
				weight=master.getWeight();
				fieldCount=parameterCount.getCardExpiryDate();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setCardExpiryDate(parameterPercent);
				break;	
			case "acctType":
				weight=master.getWeight();
				fieldCount=parameterCount.getAcctType();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setAcctType(parameterPercent);
				break;	
			case "brand":
				weight=master.getWeight();
				fieldCount=parameterCount.getBrand();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setBrand(parameterPercent);
				break;	
			case "cardholderName":
				weight=master.getWeight();
				fieldCount=parameterCount.getCardHolderName();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setCardholderName(parameterPercent);
				break;	
			case "email":
				weight=master.getWeight();
				fieldCount=parameterCount.getEmail();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setEmail(parameterPercent);
				break;	
			case "ipAddress":
				weight=master.getWeight();
				fieldCount=parameterCount.getIpAddress();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setIpAddress(parameterPercent);
				break;	
			case "platform":
				weight=master.getWeight();
				fieldCount=parameterCount.getPlatform();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setPlatform(parameterPercent);
				break;	
			case "deviceModel":
				weight=master.getWeight();
				fieldCount=parameterCount.getDeviceModel();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setDeviceModel(parameterPercent);
				break;	
			case "osName":
				weight=master.getWeight();
				fieldCount=parameterCount.getOsName();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setOsName(parameterPercent);
				break;		
			case "osVersion":
				weight=master.getWeight();
				fieldCount=parameterCount.getOsVersion();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setOsVersion(parameterPercent);
				break;	
			case "deviceName":
				weight=master.getWeight();
				fieldCount=parameterCount.getDeviceName();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setDeviceName(parameterPercent);
				break;	
			case "timeZone":
				weight=master.getWeight();
				fieldCount=parameterCount.getTimeZone();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setTimeZone(parameterPercent);
				break;	
			case "browserIP":
				weight=master.getWeight();
				fieldCount=parameterCount.getBrowserIP();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setBrowserIP(parameterPercent);
				break;	
			case "browserLanguage":
				weight=master.getWeight();
				fieldCount=parameterCount.getBrowserLanguage();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setBrowserLanguage(parameterPercent);
				break;	
			case "browserAcceptHeader":
				weight=master.getWeight();
				fieldCount=parameterCount.getBrowserAcceptHeader();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setBrowserAcceptHeader(parameterPercent);
				break;	
			case "purchaseAmount":
				weight=master.getWeight();
				fieldCount=parameterCount.getPurchaseAmount();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setPurchaseAmount(parameterPercent);
				break;	
			case "purchaseCurrency":
				weight=master.getWeight();
				fieldCount=parameterCount.getPurchaseCurrency();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setPurchaseCurrency(parameterPercent);
				break;	
			case "txndateTime":
				weight=master.getWeight();
				fieldCount=parameterCount.getTxnDateTime();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setTxndateTime(parameterPercent);
				break;	
			case "merchantName":
				weight=master.getWeight();
				fieldCount=parameterCount.getMerchantName();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setMerchantName(parameterPercent);
				break;
			case "merchantMCC":
				weight=master.getWeight();
				fieldCount=parameterCount.getMerchantMCC();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setMerchantMCC(parameterPercent);
				break;	
			case "merchantCntryCode":
				weight=master.getWeight();
				fieldCount=parameterCount.getMerchantCntryCode();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setMerchantCntryCode(parameterPercent);
				break;	
			case "shippingAddress":
				weight=master.getWeight();
				fieldCount=parameterCount.getShippingAddress();
				parameterPercent=getPercentage(totalTxnCount,fieldCount,weight);
				grandScore+=Integer.valueOf(parameterPercent);
				grandTotal+=100;
				parameterPercentage.setShippingAddress(parameterPercent);
				break;	
			}	
			
			
	}*/
	
	/*private String getPercentage(int totalTxnCount, int fieldCount, int weight) {
		int per=((fieldCount*weight)/(totalTxnCount*weight))*100;
		return String.valueOf(per);
	}*/
}
